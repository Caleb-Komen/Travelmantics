package com.foozenergy.travelmantics;

public class TravelAdapter {
}
