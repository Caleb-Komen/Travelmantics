package com.foozenergy.travelmantics;

public class Travel {
}
